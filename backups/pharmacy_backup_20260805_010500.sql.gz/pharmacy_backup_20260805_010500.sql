-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: pharmacy_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `pharmacy_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pharmacy_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pharmacy_db`;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(255) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `email_sent` bit(1) DEFAULT NULL,
  `error_message` varchar(255) DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `onedrive_uploaded` bit(1) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicines`
--

DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `generic_name` varchar(200) DEFAULT NULL,
  `gst_rate` decimal(5,2) NOT NULL,
  `hsn_code` varchar(20) DEFAULT NULL,
  `low_stock_threshold` int DEFAULT NULL,
  `manufacturer` varchar(200) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) NOT NULL,
  `stock_quantity` int NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `rack_number` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicines`
--

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
INSERT INTO `medicines` VALUES (1,'34324234','2026-08-03 21:07:37.560854','2026-08-12','medformin',5.00,NULL,10,NULL,'medformin',150.00,165.00,96,'2026-08-03 21:33:23.685556',NULL,NULL),(2,'25s2gtc195','2026-08-03 21:39:34.971663','2026-09-18','dapaturn',5.00,NULL,10,NULL,'dapaturn m 10',124.50,136.95,49,'2026-08-03 21:40:34.210795',NULL,NULL),(3,'AB26022','2026-08-03 21:39:35.020448','2026-09-16','vildawick',5.00,NULL,10,NULL,'vildawick met 50-500 mg',167.78,184.56,67,'2026-08-03 21:40:34.209709',NULL,NULL),(4,'sdf-sdfs8568','2026-08-04 17:52:49.278914','2026-08-29','clime',12.00,NULL,10,NULL,'cleme',540.00,594.00,12,'2026-08-04 17:52:49.348480',NULL,NULL);
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `gst_amount` decimal(10,2) NOT NULL,
  `gst_rate` decimal(5,2) NOT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `purchase_date` datetime(6) DEFAULT NULL,
  `quantity` int NOT NULL,
  `supplier_name` varchar(200) DEFAULT NULL,
  `total` decimal(12,2) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `medicine_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKal92jfnl4o3ueqvq8t6ivfdml` (`created_by`),
  KEY `FKnrqy9oo8jmlwmx1wrufl95cxa` (`medicine_id`),
  CONSTRAINT `FKal92jfnl4o3ueqvq8t6ivfdml` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKnrqy9oo8jmlwmx1wrufl95cxa` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,'2026-08-03 21:07:37.630993',750.00,5.00,'1224424','2026-08-03 21:07:37.629990',100,'sun forma',15750.00,150.00,5,1),(2,'2026-08-03 21:39:34.997787',311.25,5.00,'tf-908764er','2026-08-03 21:39:34.996762',50,'ganesh',6536.25,124.50,5,2),(3,'2026-08-03 21:39:35.042175',587.23,5.00,'INCL-45781L','2026-08-03 21:39:35.040166',70,'ELDER',12331.83,167.78,5,3),(4,'2026-08-04 17:52:49.342942',777.60,12.00,'2341','2026-08-04 17:52:49.341942',12,'guru',7257.60,540.00,5,4);
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `returns` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `quantity` int NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `refund_amount` decimal(12,2) NOT NULL,
  `return_date` datetime(6) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `medicine_id` bigint NOT NULL,
  `sale_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnubyybpnmb0fnoqvkk1gk88r0` (`created_by`),
  KEY `FKcbnlsmvasjiprjvimvdsodm5h` (`medicine_id`),
  KEY `FKjs7wcrjlk7r7vpfbj8tesaxw8` (`sale_id`),
  CONSTRAINT `FKcbnlsmvasjiprjvimvdsodm5h` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`),
  CONSTRAINT `FKjs7wcrjlk7r7vpfbj8tesaxw8` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `FKnubyybpnmb0fnoqvkk1gk88r0` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ofx66keruapi6vyqpv6f2or37` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN'),(2,'PHARMACIST'),(3,'SALES');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `customer_name` varchar(200) DEFAULT NULL,
  `customer_phone` varchar(15) DEFAULT NULL,
  `discount` decimal(12,2) NOT NULL,
  `gst_amount` decimal(12,2) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `sale_date` datetime(6) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `created_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_l49hpufyld5nu2vqun7811hgh` (`invoice_number`),
  KEY `FKhck7oc1oupp6pibt2tn2wge50` (`created_by`),
  CONSTRAINT `FKhck7oc1oupp6pibt2tn2wge50` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'2026-08-03 21:19:11.585118','test','7485478974',0.00,24.75,'INV-20260804-1001','CARD','2026-08-03 21:19:11.577937',495.00,519.75,5),(2,'2026-08-03 21:33:23.678225','demo','7844444874',0.00,8.25,'INV-20260804-1002','UPI','2026-08-03 21:33:23.678226',165.00,173.25,5),(3,'2026-08-03 21:40:34.198236','MANI','8974589784',0.00,34.53,'INV-20260804-1003','CASH','2026-08-03 21:40:34.196953',690.63,725.16,5);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_items`
--

DROP TABLE IF EXISTS `sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `gst_amount` decimal(10,2) NOT NULL,
  `gst_rate` decimal(5,2) NOT NULL,
  `quantity` int NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `medicine_id` bigint NOT NULL,
  `sale_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb4v5bpg7gmqosgx8n88327r50` (`medicine_id`),
  KEY `FK5yb2flnwhyerqi7ooxpj1wfal` (`sale_id`),
  CONSTRAINT `FK5yb2flnwhyerqi7ooxpj1wfal` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `FKb4v5bpg7gmqosgx8n88327r50` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_items`
--

LOCK TABLES `sales_items` WRITE;
/*!40000 ALTER TABLE `sales_items` DISABLE KEYS */;
INSERT INTO `sales_items` VALUES (1,24.75,5.00,3,519.75,165.00,1,1),(2,8.25,5.00,1,173.25,165.00,1,2),(3,27.68,5.00,3,581.36,184.56,3,3),(4,6.85,5.00,1,143.80,136.95,2,3);
/*!40000 ALTER TABLE `sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`),
  KEY `FKp56c1712k691lhsyewcssf40f` (`role_id`),
  CONSTRAINT `FKp56c1712k691lhsyewcssf40f` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,NULL,_binary '','System Administrator','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',NULL,'admin',1),(3,NULL,_binary '','System Administrator','admin123',NULL,'admin1',1),(4,'2026-08-03 20:26:05.906047',_binary '','System Admin','$2a$10$EqPKn22QekkZ13UKOisWveqFYNGa8AKCyFdMRlK7aLoHFQrE7X8cO','2026-08-03 20:26:05.906047','admin2',1),(5,'2026-08-03 20:50:08.862246',_binary '','System Admin','$2a$10$J8Gj22mTjz69uM8gVrFoseJH4NfkBOGmjXz4aqFHyMk4f/HqVDBKO','2026-08-03 20:50:08.862246','admin3',2),(6,'2026-08-03 20:50:28.470699',_binary '','System Admin','$2a$10$OzyfYW95kxvnKj4CcLSUXuWZFR9T0eFFmmFt0mCZmQVvIEuMfWUHm','2026-08-03 20:50:28.470699','admin4',3);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pharmacy_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-05  1:05:00
