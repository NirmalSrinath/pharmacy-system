-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: pharmacy_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `pharmacy_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pharmacy_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pharmacy_db`;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `file_size` bigint DEFAULT NULL,
  `backup_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `email_sent` tinyint(1) DEFAULT '0',
  `onedrive_uploaded` tinyint(1) DEFAULT '0',
  `error_message` text,
  `created_by` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `backup_history_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','create roles table','SQL','V1__create_roles_table.sql',-573348320,'root','2026-08-05 15:36:00',41,1),(2,'2','create users table','SQL','V2__create_users_table.sql',-1426719424,'root','2026-08-05 15:36:00',62,1),(3,'3','create medicines table','SQL','V3__create_medicines_table.sql',-540958141,'root','2026-08-05 15:36:00',29,1),(4,'4','create sales table','SQL','V4__create_sales_table.sql',-427618154,'root','2026-08-05 15:36:00',45,1),(5,'5','create sales items table','SQL','V5__create_sales_items_table.sql',-320998594,'root','2026-08-05 15:36:00',49,1),(6,'6','create purchases table','SQL','V6__create_purchases_table.sql',1141285641,'root','2026-08-05 15:36:00',40,1),(7,'7','create returns table','SQL','V7__create_returns_table.sql',-1448399501,'root','2026-08-05 15:36:01',51,1),(8,'8','seed admin user','SQL','V8__seed_admin_user.sql',-64870973,'root','2026-08-05 15:36:01',4,1),(9,'9','add rack number and type to medicines','SQL','V9__add_rack_number_and_type_to_medicines.sql',1074698252,'root','2026-08-05 15:36:01',102,1),(10,'10','create backup history table','SQL','V10__create_backup_history_table.sql',-701521407,'root','2026-08-05 15:36:01',42,1),(11,'11','seed role','SQL','V11__seed_role.sql',1214952692,'root','2026-08-05 15:36:01',12,1),(12,'12','create user roles table','SQL','V12__create_user_roles_table.sql',936053999,'root','2026-08-05 15:36:01',165,1),(13,'14','add active to medicines','SQL','V14__add_active_to_medicines.sql',-1710240053,'root','2026-08-05 16:50:37',52,1),(14,'15','add version optimistic lock','SQL','V15__add_version_optimistic_lock.sql',-263397135,'root','2026-08-05 17:05:06',86,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicines`
--

DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `generic_name` varchar(200) DEFAULT NULL,
  `manufacturer` varchar(200) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `stock_quantity` int NOT NULL DEFAULT '0',
  `sale_price` decimal(10,2) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `gst_rate` decimal(5,2) NOT NULL DEFAULT '12.00',
  `hsn_code` varchar(20) DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `low_stock_threshold` int DEFAULT '10',
  `rack_number` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicines`
--

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
INSERT INTO `medicines` VALUES (1,'metFormn 500','met',NULL,'23435',8,15.40,14.00,5.00,NULL,'2026-08-19',5,'a-10','tablet','2026-08-05 10:17:10','2026-08-05 11:50:36',0,1),(2,'Paracetamol 500mg','Paracetamol',NULL,'BATCH001',500,2.75,2.50,12.00,NULL,'2027-06-30',50,'A1','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(3,'Amoxicillin 250mg','Amoxicillin',NULL,'BATCH002',200,9.63,8.75,12.00,NULL,'2027-03-15',30,'A2','capsule','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(4,'Cetirizine 10mg','Cetirizine HCl',NULL,'BATCH003',300,3.52,3.20,12.00,NULL,'2027-09-20',40,'B1','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(5,'Omeprazole 20mg','Omeprazole',NULL,'BATCH004',150,13.75,12.50,18.00,NULL,'2027-12-01',25,'B2','capsule','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(6,'Metformin 500mg','Metformin HCl',NULL,'BATCH005',395,5.50,5.00,5.00,NULL,'2027-08-15',60,'C1','tablet','2026-08-05 10:25:12','2026-08-05 13:06:38',1,1),(7,'Azithromycin 500mg','Azithromycin',NULL,'BATCH006',100,19.80,18.00,18.00,NULL,'2027-05-10',20,'C2','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(8,'Pantoprazole 40mg','Pantoprazole',NULL,'BATCH007',250,10.45,9.50,12.00,NULL,'2027-11-30',35,'D1','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(9,'Montelukast 10mg','Montelukast Sodium',NULL,'BATCH008',176,15.40,14.00,18.00,NULL,'2027-07-25',25,'D2','tablet','2026-08-05 10:25:12','2026-08-05 13:06:38',1,1),(10,'Cough Syrup 100ml','Dextromethorphan',NULL,'BATCH009',120,49.50,45.00,12.00,NULL,'2027-04-20',15,'E1','syrup','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(11,'Betamethasone Cream','Betamethasone Valerate',NULL,'BATCH010',80,35.20,32.00,18.00,NULL,'2027-10-05',20,'E2','ointment','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(12,'Salbutamol Inhaler','Salbutamol Sulphate',NULL,'BATCH011',50,203.50,185.00,18.00,NULL,'2027-06-15',10,'F1','inhaler','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(13,'Ibuprofen 400mg','Ibuprofen',NULL,'BATCH012',350,4.95,4.50,12.00,NULL,'2027-08-30',50,'F2','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(14,'Vitamin D3 Drops','Cholecalciferol',NULL,'BATCH013',199,74.80,68.00,5.00,NULL,'2027-12-31',30,'G1','drops','2026-08-05 10:25:12','2026-08-05 13:06:38',1,1),(15,'Metoprolol 50mg','Metoprolol Succinate',NULL,'BATCH014',220,7.98,7.25,5.00,NULL,'2027-09-10',25,'G2','tablet','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(16,'Povidone Iodine 10%','Povidone Iodine',NULL,'BATCH015',90,60.50,55.00,12.00,NULL,'2028-01-20',15,'H1','solution','2026-08-05 10:25:12','2026-08-05 10:25:12',1,0),(17,'Amoxicillin 250mg','Amoxicillin',NULL,'BATCH002',123,9.63,8.75,12.00,NULL,'2026-11-20',10,'A2','tablet','2026-08-05 13:22:43','2026-08-05 13:22:44',1,1),(18,'Amoxicillin 250mg','Amoxicillin',NULL,'BATCH002',11,9.63,8.75,12.00,NULL,'2026-08-28',10,'A2','tablet','2026-08-05 14:03:16','2026-08-05 14:03:16',1,1);
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `medicine_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `gst_rate` decimal(5,2) NOT NULL,
  `gst_amount` decimal(10,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `supplier_name` varchar(200) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `purchase_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `medicine_id` (`medicine_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`),
  CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,1,10,14.00,5.00,7.00,147.00,'guru','12345','2026-08-05 10:17:10',1,'2026-08-05 10:17:10',0),(2,2,500,2.50,12.00,150.00,1400.00,'MedSupply Co','INV-2026-001','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(3,3,200,8.75,12.00,210.00,1960.00,'PharmaDist Ltd','INV-2026-002','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(4,4,300,3.20,12.00,115.20,1075.20,'MedSupply Co','INV-2026-003','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(5,5,150,12.50,18.00,337.50,2212.50,'HealthCare Pharma','INV-2026-004','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(6,6,400,5.00,5.00,100.00,2100.00,'DiabetCare Inc','INV-2026-005','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(7,7,100,18.00,18.00,324.00,2124.00,'PharmaDist Ltd','INV-2026-006','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(8,8,250,9.50,12.00,285.00,2660.00,'HealthCare Pharma','INV-2026-007','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(9,9,180,14.00,18.00,453.60,2973.60,'AllergyMed Labs','INV-2026-008','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(10,10,120,45.00,12.00,648.00,6048.00,'SyrupMakers Ltd','INV-2026-009','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(11,11,80,32.00,18.00,460.80,3020.80,'DermaCare Pharma','INV-2026-010','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(12,12,50,185.00,18.00,1665.00,10915.00,'RespiCare Inc','INV-2026-011','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(13,13,350,4.50,12.00,189.00,1764.00,'PainRelief Pharma','INV-2026-012','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(14,14,200,68.00,5.00,680.00,14280.00,'VitaHealth Labs','INV-2026-013','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(15,15,220,7.25,5.00,79.75,1674.75,'CardioMed Pvt','INV-2026-014','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(16,16,90,55.00,12.00,594.00,5544.00,'AntisepticSupply','INV-2026-015','2026-08-05 10:25:12',1,'2026-08-05 10:25:12',0),(17,17,123,8.75,12.00,129.15,1205.40,'Guru','784578','2026-08-05 13:22:44',1,'2026-08-05 13:22:44',0),(18,18,11,8.75,12.00,11.55,107.80,'hmks','313123','2026-08-05 14:03:16',1,'2026-08-05 14:03:16',0);
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `returns` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` bigint DEFAULT NULL,
  `medicine_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `refund_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `return_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `medicine_id` (`medicine_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`),
  CONSTRAINT `returns_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN'),(2,'PHARMACIST'),(3,'SALESPERSON');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(200) DEFAULT NULL,
  `customer_phone` varchar(15) DEFAULT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `gst_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(20) DEFAULT 'CASH',
  `created_by` bigint DEFAULT NULL,
  `sale_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'Kala','8794561236','INV-20260805-1001',30.80,1.54,0.00,32.34,'CARD',1,'2026-08-05 10:18:13','2026-08-05 10:18:13'),(2,'test','7894561236','INV-20260805-1002',15.40,2.77,0.00,18.17,'CASH',1,'2026-08-05 10:26:30','2026-08-05 10:26:30'),(3,'demo','7894561236','INV-20260806-1001',148.50,13.44,0.00,161.94,'UPI',1,'2026-08-05 13:06:38','2026-08-05 13:06:38');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_items`
--

DROP TABLE IF EXISTS `sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` bigint NOT NULL,
  `medicine_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `gst_rate` decimal(5,2) NOT NULL,
  `gst_amount` decimal(10,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `medicine_id` (`medicine_id`),
  CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_items_ibfk_2` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_items`
--

LOCK TABLES `sales_items` WRITE;
/*!40000 ALTER TABLE `sales_items` DISABLE KEYS */;
INSERT INTO `sales_items` VALUES (1,1,1,2,15.40,5.00,1.54,32.34),(2,2,9,1,15.40,18.00,2.77,18.17),(3,3,6,5,5.50,5.00,1.38,28.88),(4,3,14,1,74.80,5.00,3.74,78.54),(5,3,9,3,15.40,18.00,8.32,54.52);
/*!40000 ALTER TABLE `sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1),(3,2),(3,3);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2a$10$teLWY8wTVxdF9eOFVYef4OlXfuUBqaG5RmaZspSANDJ2DY.1G5UIO','System Administrator',1,'2026-08-05 15:36:01','2026-08-05 15:36:01'),(3,'nirmal','$2a$10$6pM6LVzO0kJX/ve3tnD2iee6vowsoNXIPOX19gwJmmGxVuGSF.A2C','Nirmal Srinath',1,'2026-08-05 10:12:05','2026-08-05 10:12:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pharmacy_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-06  1:05:00
